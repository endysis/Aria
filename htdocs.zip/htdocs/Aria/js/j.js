$(document).ready(function () {
   swiper = new Swiper('.swiper-container'); 
   

  
  
});
