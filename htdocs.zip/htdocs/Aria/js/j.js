$(document).ready(function () {
   swiper = new Swiper('.swiper-container'); 
   

  
  
});

$(document).on ("click", "#mapIcon", function () {
	//alert( "Handler for .click() called." );
	placeMarker(lat: -25.363, lng: 131.044);
	});
	
	
	
	

function placeMarker(location) {
    var marker = new google.maps.Marker({
        position: location, 
        map: map
    });
}