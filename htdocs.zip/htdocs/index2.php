<html>
 <head>
 <Title>Registration Form</Title>
 <style type="text/css">
     body { background-color: #fff; border-top: solid 10px #000;
         color: #333; font-size: .85em; margin: 20; padding: 20;
         font-family: "Segoe UI", Verdana, Helvetica, Sans-Serif;
     }
     h1, h2, h3,{ color: #000; margin-bottom: 0; padding-bottom: 0; }
     h1 { font-size: 2em; }
     h2 { font-size: 1.75em; }
     h3 { font-size: 1.2em; }
     table { margin-top: 0.75em; }
     th { font-size: 1.2em; text-align: left; border: none; padding-left: 0; }
     td { padding: 0.25em 2em 0.25em 0em; border: 0 none; }
 </style>
 </head>
 <body>
 <h1>Add Info Here!</h1>
 <p>Fill in your name and email address, then click <strong>Submit</strong> to register.</p>
 <form method="post" action="index2.php" enctype="multipart/form-data" >
       Name  <input type="text" name="artist_name" id="artist_name"/></br>
       Type <input type="text" name="type" id="type"/></br>
	   Description <input type="text" name="description" id="description"/></br>
	   Fgenre <input type="text" name="fgenre" id="fgenre"/></br>
	   Lat <input type="text" name="lat" id="lat"/></br>
	   Long <input type="text" name="long" id="long"/></br>
       <input type="submit" name="submit" value="Submit" />
 </form>
 
 <?php
	 // DB connection info
 $host = "localhost";
 $user = "root";
 $pwd = "ripley";
 $db = "ariadb";
 // Connect to database.
 try {
	 echo "Connected";
     $conn = new PDO( "mysql:host=$host;dbname=$db", $user, $pwd);
     $conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
 }
 catch(Exception $e){
     die(var_dump($e));
 }
 
 if(!empty($_POST)) {
 try {
     $artist_name = $_POST['artist_name'];
     $type = $_POST['type'];
	 $description = $_POST['description'];
	 $fgenre = $_POST['fgenre'];
	 $lat = $_POST['lat'];
	 $long = $_POST['long'];
     // Insert data
     $sql_insert = "INSERT INTO `mtbl` (`artist_name`,`type`,`description`,`fgenre`,`lat`,`long`) 
                    VALUES (?,?,?,?,?,?)";
     $stmt = $conn->prepare($sql_insert);
     $stmt->bindValue(1, $artist_name);
     $stmt->bindValue(2, $type);
     $stmt->bindValue(3, $description);
	 $stmt->bindValue(4, $fgenre);
	 $stmt->bindValue(5, $lat);
	 $stmt->bindValue(6, $long);
     $stmt->execute();
 }
 catch(Exception $e) {
     die(var_dump($e));
 }
 echo "<h3>Your're registered!</h3>";
 }
 
 $sql_select = "SELECT * FROM mtbl";
 $stmt = $conn->query($sql_select);
 $musicians = $stmt->fetchAll(); 
 if(count($musicians) > 0) {
     echo "<h2>People who are registered:</h2>";
     echo "<table>";
     echo "<tr><th>Name</th>";
	 echo "<th>Type</th>";
     echo "<th>Description</th>";
     echo "<th>Fgenre</th>";
	 echo "<th>lat</th>";
	 echo "<th>long</th></tr>";

     foreach($musicians as $musician) {
         echo "<tr><td>".$musician['artist_name']."</td>";
         echo "<td>".$musician['type']."</td>";
         echo "<td>".$musician['description']."</td></tr>";
		 echo "<td>".$musician['fgenre']."</td></tr>";
		 echo "<td>".$musician['lat']."</td></tr>";
		 echo "<td>".$musician['long']."</td></tr>";
     }
      echo "</table>";
 } else {
     echo "<h3>No one is currently registered.</h3>";
 }
 
 
 
 
 ?>
 </body>
 </html>
 
 
 
 
 
 
 
 
 
 