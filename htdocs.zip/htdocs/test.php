<?php
	// DB connection info
	$host = "us-cdbr-azure-southcentral-f.cloudapp.net";
	$user = "b899a7072101ba";
	$pwd = "c80ab4c1";
	$db = "ariadb1";

$mysqlConnection = mysql_connect($host, $user, $pwd);
if (!$mysqlConnection)
{
  echo "Please try later.";
}
else
{
 echo "It has connected";
}
?>