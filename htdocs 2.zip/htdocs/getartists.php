<html>
 <head>
 <Title></Title>

 </head>
 <body>
 <?php
 
 /*
 $long = $_GET["long"];
 if(isset( $long)){
	 $sql = 'WHERE `long` = "0.59"';
 
 }*/ 
	 // DB connection info
 $host = "localhost";
 $user = "root";
 $pwd = "ripley";
 $db = "ariadb";
 // Connect to database.
 try {
	 echo "Connected";
     $conn = new PDO( "mysql:host=$host;dbname=$db", $user, $pwd);
     $conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
 }
 catch(Exception $e){
     die(var_dump($e));
 }
 
 
 $sql_select = "SELECT * FROM mtbl";   //  $sql_select = "SELECT * FROM mtbl ".$sql;
 $stmt = $conn->query($sql_select);
 $musicians = $stmt->fetchAll(); 
 if(count($musicians) > 0) {
     foreach($musicians as $musician) {
		 ?>
      <div class="swiper-slide">
				<div class = "contentBox">
				<div id = "pictureSec">
					<img id = "pP" src = "images/artistPics/1.jpg" alt = "Profile Picture">
				</div>
				<div id = "rightBarrier"></div>
					<p id = "nameText"><i><?php echo $musician['artist_name']?> </i></p>
					<p id = "infoText"><?php echo $musician['description']?></p>
					<div id = "bottomBarrier">
					<p id = "timeText">2 hours ago</p>
					</div>
				</div>
			</div>   
        
    <?php }
      echo "</table>";
 } else {
     echo "<h3>No one is currently registered.</h3>";
 }
 
 
 
 
 ?>
 </body>
 </html>
 
 
 
 
 
 
 
 
 
 